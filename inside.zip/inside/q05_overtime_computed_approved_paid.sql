WITH computed AS (
    SELECT em.department_key, dd.year_month, SUM(f.overtime_hours) AS computed_ot_hours
    FROM warehouse.fact_attendance_daily f
    JOIN warehouse.dim_date dd ON dd.date_key = f.date_key
    JOIN warehouse.dim_employee de ON de.employee_key = f.employee_key
    JOIN warehouse.vw_employee_month em ON em.emp_id = de.emp_id AND em.year_month = dd.year_month
    GROUP BY em.department_key, dd.year_month
),
approved AS (
    SELECT em.department_key, dd.year_month, SUM(o.approved_hours) AS approved_ot_hours
    FROM warehouse.fact_overtime_approved o
    JOIN warehouse.dim_date dd ON dd.date_key = o.date_key
    JOIN warehouse.dim_employee de ON de.employee_key = o.employee_key
    JOIN warehouse.vw_employee_month em ON em.emp_id = de.emp_id AND em.year_month = dd.year_month
    GROUP BY em.department_key, dd.year_month
),
paid AS (
    SELECT p.department_key, p.payroll_month AS year_month, SUM(p.units) AS paid_ot_hours, SUM(p.amount) AS paid_ot_amount
    FROM warehouse.fact_payroll_line p
    WHERE p.component = 'OVERTIME'
    GROUP BY p.department_key, p.payroll_month
),
months AS (SELECT DISTINCT year_month FROM warehouse.dim_date WHERE month_end BETWEEN '2026-04-01' AND '2026-09-30')
SELECT m.year_month, d.plant, d.dept_name AS department,
       ROUND(COALESCE(c.computed_ot_hours, 0), 1) AS computed_ot_hours,
       ROUND(COALESCE(a.approved_ot_hours, 0), 1) AS approved_ot_hours,
       ROUND(COALESCE(p.paid_ot_hours, 0), 1)     AS paid_ot_hours,
       ROUND(COALESCE(p.paid_ot_hours, 0) - COALESCE(c.computed_ot_hours, 0), 1) AS paid_minus_computed,
       ROUND(100.0 * (COALESCE(p.paid_ot_hours, 0) - COALESCE(c.computed_ot_hours, 0)) / NULLIF(c.computed_ot_hours, 0), 1) AS paid_vs_computed_pct,
       ROUND(COALESCE(p.paid_ot_amount, 0), 0) AS paid_ot_amount_pkr
FROM months m
CROSS JOIN warehouse.dim_department d
LEFT JOIN computed c ON c.year_month = m.year_month AND c.department_key = d.department_key
LEFT JOIN approved a ON a.year_month = m.year_month AND a.department_key = d.department_key
LEFT JOIN paid p     ON p.year_month = m.year_month AND p.department_key = d.department_key
ORDER BY m.year_month, d.plant, d.dept_name
