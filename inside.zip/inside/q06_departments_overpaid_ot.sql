WITH computed AS (
    SELECT em.department_key, dd.year_month, SUM(f.overtime_hours) AS computed_hours
    FROM warehouse.fact_attendance_daily f
    JOIN warehouse.dim_date dd ON dd.date_key = f.date_key
    JOIN warehouse.dim_employee de ON de.employee_key = f.employee_key
    JOIN warehouse.vw_employee_month em ON em.emp_id = de.emp_id AND em.year_month = dd.year_month
    GROUP BY em.department_key, dd.year_month
),
paid AS (
    SELECT department_key, payroll_month AS year_month, SUM(units) AS paid_hours
    FROM warehouse.fact_payroll_line WHERE component = 'OVERTIME'
    GROUP BY department_key, payroll_month
),
monthly AS (
    SELECT d.department_key, d.plant, d.dept_name, m.year_month,
           COALESCE(c.computed_hours, 0) AS computed_hours, COALESCE(p.paid_hours, 0) AS paid_hours
    FROM (SELECT DISTINCT year_month FROM warehouse.dim_date WHERE month_end BETWEEN '2026-04-01' AND '2026-09-30') m
    CROSS JOIN warehouse.dim_department d
    LEFT JOIN computed c ON c.year_month = m.year_month AND c.department_key = d.department_key
    LEFT JOIN paid p     ON p.year_month = m.year_month AND p.department_key = d.department_key
),
totals AS (
    SELECT department_key, plant, dept_name,
           SUM(computed_hours) AS computed_ot_hours, SUM(paid_hours) AS paid_ot_hours,
           SUM(CASE WHEN computed_hours > 0 AND paid_hours > 1.15 * computed_hours THEN 1 ELSE 0 END) AS months_over_15pct
    FROM monthly GROUP BY department_key, plant, dept_name
)
SELECT plant, dept_name AS department,
       ROUND(computed_ot_hours, 1) AS computed_ot_hours, ROUND(paid_ot_hours, 1) AS paid_ot_hours,
       ROUND(paid_ot_hours - computed_ot_hours, 1) AS excess_hours,
       ROUND(100.0 * (paid_ot_hours - computed_ot_hours) / computed_ot_hours, 1) AS excess_pct,
       months_over_15pct
FROM totals
WHERE computed_ot_hours > 0 AND paid_ot_hours > 1.15 * computed_ot_hours
ORDER BY excess_pct DESC
