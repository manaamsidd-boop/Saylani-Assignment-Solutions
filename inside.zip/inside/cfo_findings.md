# CFO findings -- Indus Weave Textiles overtime

### Finding 1 -- The overtime increase is phantom overtime in one department, approved by one person
**The number.** The monthly overtime bill rose from PKR 2,814,309 (April) to PKR 3,475,158 (September), **+23.5%**. About **75%** of that rise is hours that were approved and paid but that the biometric punches do not support. Over six months that is **3,357 hours, roughly PKR 1,665,473**, and **100% of it sits in Stitching (Faisalabad Plant)**, growing from 104 unsupported hours in April to 1,080 in September. Overtime that is actually punched is flat (6,167 hours in April, 6,066 in September), which is why HR sees "normal" attendance.

**The pattern.** All 3,174 Stitching overtime requests were approved by a single approver (`E10382`), and 647 of them were for days with **no overtime at all** on the punches. Every other approver in the company has **0** unsupported hours: their approvals match the punches to the half-hour.

**Evidence.** `analytics/evidence_1_ot_requests_vs_punches.sql`, `q05_overtime_computed_approved_paid.sql`, `q06_departments_overpaid_ot.sql` (the only department where paid overtime exceeds punched overtime by more than 15% -- by 56%).

**Action.** Suspend `E10382`'s overtime approval rights pending an audit of the 3,174 requests; make payroll release overtime only for hours that match the attendance result (a one-line join already exists in the warehouse); recover or offset the unsupported amount where the audit confirms it.

### Finding 2 -- Payroll is paying people who are not there: PKR 4,825,075
**The number.** **6 employees** were paid in all six months with **zero punches** and 884 Absent days between them -- PKR 2,877,075 -- and payroll never applied an absence deduction to any of them. They are exactly the 6 employees who have no device enrolment, so they are invisible to attendance but fully visible to payroll. Separately, **5 employees who separated between 2026-04-23 and 2026-05-18 were still paid** for 21 employee-months after their last working day -- PKR 1,948,000.

**Evidence.** `q07_paid_with_zero_attendance.sql` (rows marked `NONE -- no punches, no leave`), `q08_paid_after_separation.sql`. Cross-check: for every other employee, payroll's absence deductions equal the Absent days computed from punches, so the gap is specific to these people, not a logic difference.

**Action.** HR to verify the 6 employees physically exist and work; stop payment immediately for the 5 separated employees and recover the overpayment; add a monthly control that blocks payslips for employees with no attendance row, no leave and no separation-processing evidence.

### Finding 3 -- The rest of the increase is a planned pay revision, and leave controls are loose
**The number.** On 1 July **1,192 employees received a salary revision averaging +10.0%** (range 9.5% to 10.6%), lifting earnings per paid employee from PKR 91,463 (April) to PKR 100,337 (July). Overtime is paid at twice the hourly basic rate (monthly basic / 208, confirmed on 98.5% of overtime lines), so the cost per overtime hour rose +6.3% (PKR 509 to PKR 541) -- about **31%** of the overtime increase. This part is legitimate and should be budgeted, not treated as leakage. Genuinely worked overtime hours actually *fell* slightly (PKR -42,274 effect on the bill).

A smaller control gap: **20 employees have already taken more approved Annual leave in six months than their full-year entitlement** (109 days beyond the allowance in total).

**Evidence.** `q09_payroll_cost_per_employee_by_dept.sql` (the +10% step in July in every department), `q10_annual_leave_over_entitlement.sql`, the April-to-September bridge in section 8.

**Action.** Budget overtime at the post-revision rate so the July step is not read as a trend; enforce the leave balance check at HR approval (step 2 of the workflow) so entitlement is checked before the second approval, not after.
