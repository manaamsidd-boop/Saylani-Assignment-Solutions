WITH monthly AS (
    SELECT p.department_key, p.payroll_month,
           COUNT(DISTINCT p.employee_key) AS paid_headcount_keys,
           SUM(p.amount) AS total_earnings
    FROM warehouse.fact_payroll_line p
    WHERE p.component_type = 'EARNING'
    GROUP BY p.department_key, p.payroll_month
),
emp_count AS (
    SELECT p.department_key, p.payroll_month, COUNT(DISTINCT de.emp_id) AS employees_paid
    FROM warehouse.fact_payroll_line p JOIN warehouse.dim_employee de ON de.employee_key = p.employee_key
    WHERE p.component_type = 'EARNING'
    GROUP BY p.department_key, p.payroll_month
),
cost AS (
    SELECT m.department_key, m.payroll_month, e.employees_paid, m.total_earnings,
           m.total_earnings / e.employees_paid AS cost_per_employee
    FROM monthly m JOIN emp_count e ON e.department_key = m.department_key AND e.payroll_month = m.payroll_month
)
SELECT c.payroll_month, d.plant, d.dept_name AS department, c.employees_paid,
       ROUND(c.total_earnings, 0) AS total_earnings_pkr,
       ROUND(c.cost_per_employee, 0) AS cost_per_employee_pkr,
       ROUND(LAG(c.cost_per_employee) OVER w, 0) AS previous_month_cost_per_employee,
       ROUND(c.cost_per_employee - LAG(c.cost_per_employee) OVER w, 0) AS mom_change_pkr,
       ROUND(100.0 * (c.cost_per_employee / LAG(c.cost_per_employee) OVER w - 1), 2) AS mom_change_pct
FROM cost c JOIN warehouse.dim_department d ON d.department_key = c.department_key
WINDOW w AS (PARTITION BY c.department_key ORDER BY c.payroll_month)
ORDER BY d.plant, d.dept_name, c.payroll_month
