WITH post_sep AS (
    SELECT de.emp_id, p.payroll_month,
           SUM(CASE WHEN p.component_type = 'EARNING' THEN p.amount ELSE 0 END) AS earnings_pkr,
           SUM(CASE WHEN p.component = 'BASIC' THEN p.amount ELSE 0 END) AS basic_pkr
    FROM warehouse.fact_payroll_line p
    JOIN warehouse.dim_employee de ON de.employee_key = p.employee_key
    WHERE de.separation_date IS NOT NULL
      AND p.payroll_month || '-01' > de.separation_date
    GROUP BY de.emp_id, p.payroll_month
)
SELECT ps.emp_id, cur.full_name, dep.dept_name AS department, dep.plant, cur.separation_date,
       COUNT(*) AS months_paid_after_separation,
       MIN(ps.payroll_month) AS first_month_paid_after, MAX(ps.payroll_month) AS last_month_paid_after,
       ROUND(SUM(ps.earnings_pkr), 0) AS earnings_paid_after_pkr
FROM post_sep ps
JOIN warehouse.dim_employee cur ON cur.emp_id = ps.emp_id AND cur.is_current = 1
JOIN warehouse.dim_department dep ON dep.department_key = cur.department_key
GROUP BY ps.emp_id, cur.full_name, dep.dept_name, dep.plant, cur.separation_date
ORDER BY earnings_paid_after_pkr DESC
