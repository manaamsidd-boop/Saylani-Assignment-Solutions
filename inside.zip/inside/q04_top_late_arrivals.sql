WITH late AS (
    SELECT de.emp_id, SUM(f.is_late) AS late_arrivals, SUM(f.late_minutes) AS total_late_minutes,
           SUM(CASE WHEN f.status = 'Present' AND f.is_scheduled_day = 1 THEN 1 ELSE 0 END) AS present_working_days
    FROM warehouse.fact_attendance_daily f
    JOIN warehouse.dim_employee de ON de.employee_key = f.employee_key
    GROUP BY de.emp_id
),
ranked AS (
    SELECT l.*, ROW_NUMBER() OVER (ORDER BY l.late_arrivals DESC, l.total_late_minutes DESC, l.emp_id) AS rank_no
    FROM late l
)
SELECT r.rank_no, r.emp_id, cur.full_name, dep.dept_name AS department, dep.plant,
       r.late_arrivals, r.present_working_days, ROUND(100.0 * r.late_arrivals / r.present_working_days, 1) AS late_rate_pct, r.total_late_minutes
FROM ranked r
JOIN warehouse.dim_employee cur ON cur.emp_id = r.emp_id AND cur.is_current = 1
JOIN warehouse.dim_department dep ON dep.department_key = cur.department_key
WHERE r.rank_no <= 10
ORDER BY r.rank_no
