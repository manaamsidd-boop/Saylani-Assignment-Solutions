WITH month_ends AS (
    SELECT DISTINCT year_month, month_end
    FROM warehouse.dim_date
    WHERE month_end BETWEEN '2026-04-01' AND '2026-09-30'
),
dept_months AS (
    SELECT m.year_month, m.month_end, d.department_key, d.plant, d.dept_name
    FROM month_ends m CROSS JOIN warehouse.dim_department d
),
active AS (
    SELECT dm.year_month, dm.department_key, COUNT(DISTINCT e.emp_id) AS headcount
    FROM dept_months dm
    JOIN warehouse.dim_employee e
      ON dm.month_end BETWEEN e.valid_from AND e.valid_to
     AND e.department_key = dm.department_key
     AND e.hire_date <= dm.month_end
     AND (e.separation_date IS NULL OR e.separation_date > dm.month_end)
    GROUP BY dm.year_month, dm.department_key
)
SELECT dm.year_month, dm.plant, dm.dept_name AS department, COALESCE(a.headcount, 0) AS headcount
FROM dept_months dm
LEFT JOIN active a ON a.year_month = dm.year_month AND a.department_key = dm.department_key
ORDER BY dm.year_month, dm.plant, dm.dept_name
