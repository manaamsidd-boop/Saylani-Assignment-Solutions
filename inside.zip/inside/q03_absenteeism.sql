SELECT dd.year_month, dep.plant,
       SUM(CASE WHEN f.is_scheduled_day = 1 AND f.status <> 'On Leave' THEN 1 ELSE 0 END) AS expected_working_days,
       SUM(CASE WHEN f.status = 'Absent' THEN 1 ELSE 0 END)                               AS absent_days,
       SUM(CASE WHEN f.status = 'On Leave' THEN 1 ELSE 0 END)                             AS approved_leave_days_excluded,
       ROUND(100.0 * SUM(CASE WHEN f.status = 'Absent' THEN 1 ELSE 0 END)
             / NULLIF(SUM(CASE WHEN f.is_scheduled_day = 1 AND f.status <> 'On Leave' THEN 1 ELSE 0 END), 0), 2) AS absenteeism_pct
FROM warehouse.fact_attendance_daily f
JOIN warehouse.dim_date dd ON dd.date_key = f.date_key
JOIN warehouse.dim_employee de ON de.employee_key = f.employee_key
JOIN warehouse.vw_employee_month em ON em.emp_id = de.emp_id AND em.year_month = dd.year_month
JOIN warehouse.dim_department dep ON dep.department_key = em.department_key
GROUP BY dd.year_month, dep.plant
ORDER BY dd.year_month, dep.plant
