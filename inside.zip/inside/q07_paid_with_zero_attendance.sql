WITH paid AS (
    SELECT de.emp_id, p.payroll_month,
           SUM(CASE WHEN p.component_type = 'EARNING' THEN p.amount ELSE 0 END) AS gross_earnings_pkr
    FROM warehouse.fact_payroll_line p
    JOIN warehouse.dim_employee de ON de.employee_key = p.employee_key
    GROUP BY de.emp_id, p.payroll_month
),
attendance AS (
    SELECT de.emp_id, dd.year_month,
           SUM(CASE WHEN f.status IN ('Present', 'Missing Punch') THEN 1 ELSE 0 END) AS punched_days,
           SUM(CASE WHEN f.status = 'On Leave' THEN 1 ELSE 0 END) AS leave_days,
           SUM(CASE WHEN f.status = 'Absent' THEN 1 ELSE 0 END)   AS absent_days
    FROM warehouse.fact_attendance_daily f
    JOIN warehouse.dim_date dd ON dd.date_key = f.date_key
    JOIN warehouse.dim_employee de ON de.employee_key = f.employee_key
    GROUP BY de.emp_id, dd.year_month
)
SELECT pd.payroll_month, pd.emp_id, cur.full_name, dep.dept_name AS department, dep.plant,
       cur.hire_date, cur.separation_date,
       COALESCE(a.punched_days, 0) AS punched_days, COALESCE(a.leave_days, 0) AS leave_days, COALESCE(a.absent_days, 0) AS absent_days,
       pd.gross_earnings_pkr,
       CASE WHEN a.emp_id IS NULL AND cur.separation_date < pd.payroll_month || '-01' THEN 'separated before this month'
            WHEN COALESCE(a.leave_days, 0) > 0 THEN 'approved leave'
            WHEN a.emp_id IS NOT NULL AND COALESCE(a.absent_days, 0) = 0 THEN 'only days off in the month (left on a holiday / Sunday)'
            ELSE 'NONE -- no punches, no leave' END AS explained_by
FROM paid pd
LEFT JOIN attendance a ON a.emp_id = pd.emp_id AND a.year_month = pd.payroll_month
JOIN warehouse.dim_employee cur ON cur.emp_id = pd.emp_id AND cur.is_current = 1
JOIN warehouse.dim_department dep ON dep.department_key = cur.department_key
WHERE COALESCE(a.punched_days, 0) = 0
ORDER BY pd.gross_earnings_pkr DESC
