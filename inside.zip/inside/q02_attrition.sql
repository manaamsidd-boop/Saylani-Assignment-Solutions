WITH months AS (
    SELECT DISTINCT year_month, month_start, month_end, date(month_start, '-1 day') AS prev_month_end
    FROM warehouse.dim_date
    WHERE month_end BETWEEN '2026-04-01' AND '2026-09-30'
),
snapshots AS (
    SELECT month_end AS snap_date FROM months UNION SELECT prev_month_end FROM months
),
headcount AS (
    SELECT s.snap_date, e.department_key, COUNT(DISTINCT e.emp_id) AS headcount
    FROM snapshots s
    JOIN warehouse.dim_employee e
      ON s.snap_date BETWEEN e.valid_from AND e.valid_to
     AND e.hire_date <= s.snap_date
     AND (e.separation_date IS NULL OR e.separation_date > s.snap_date)
    GROUP BY s.snap_date, e.department_key
),
separations AS (
    SELECT m.year_month, e.department_key, COUNT(DISTINCT e.emp_id) AS separations
    FROM months m
    JOIN warehouse.dim_employee e
      ON e.separation_date BETWEEN m.month_start AND m.month_end
     AND e.separation_date BETWEEN e.valid_from AND e.valid_to
    GROUP BY m.year_month, e.department_key
)
SELECT m.year_month, d.plant, d.dept_name AS department,
       COALESCE(o.headcount, 0) AS opening_headcount,
       COALESCE(c.headcount, 0) AS closing_headcount,
       ROUND((COALESCE(o.headcount, 0) + COALESCE(c.headcount, 0)) / 2.0, 1) AS average_headcount,
       COALESCE(s.separations, 0) AS separations,
       ROUND(100.0 * COALESCE(s.separations, 0) / NULLIF((COALESCE(o.headcount, 0) + COALESCE(c.headcount, 0)) / 2.0, 0), 2) AS attrition_pct
FROM months m
CROSS JOIN warehouse.dim_department d
LEFT JOIN headcount o ON o.snap_date = m.prev_month_end AND o.department_key = d.department_key
LEFT JOIN headcount c ON c.snap_date = m.month_end      AND c.department_key = d.department_key
LEFT JOIN separations s ON s.year_month = m.year_month  AND s.department_key = d.department_key
ORDER BY m.year_month, d.plant, d.dept_name
