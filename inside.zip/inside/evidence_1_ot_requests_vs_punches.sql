WITH req AS (
    SELECT o.request_id, de.emp_id, o.approver_id, o.approved_hours, o.employee_key, o.department_key, o.date_key, dd.year_month
    FROM warehouse.fact_overtime_approved o
    JOIN warehouse.dim_employee de ON de.employee_key = o.employee_key
    JOIN warehouse.dim_date dd ON dd.date_key = o.date_key
),
worked AS (
    SELECT employee_key, date_key, overtime_hours, status FROM warehouse.fact_attendance_daily
),
rate AS (
    SELECT de.emp_id, p.payroll_month, SUM(p.amount) * 1.0 / SUM(p.units) AS pkr_per_hour
    FROM warehouse.fact_payroll_line p JOIN warehouse.dim_employee de ON de.employee_key = p.employee_key
    WHERE p.component = 'OVERTIME' AND p.units > 0
    GROUP BY de.emp_id, p.payroll_month
)
SELECT r.request_id, r.emp_id, r.approver_id, r.year_month, dep.plant, dep.dept_name AS department,
       r.approved_hours, COALESCE(w.overtime_hours, 0) AS computed_hours, COALESCE(w.status, 'no attendance row') AS day_status,
       MAX(r.approved_hours - COALESCE(w.overtime_hours, 0), 0) AS unsupported_hours,
       ROUND(MAX(r.approved_hours - COALESCE(w.overtime_hours, 0), 0) * rt.pkr_per_hour, 2) AS unsupported_pkr,
       CASE WHEN COALESCE(w.overtime_hours, 0) = 0 THEN 'no overtime on punches'
            WHEN w.overtime_hours < r.approved_hours THEN 'partly supported' ELSE 'fully supported' END AS support
FROM req r
JOIN warehouse.dim_department dep ON dep.department_key = r.department_key
LEFT JOIN worked w ON w.employee_key = r.employee_key AND w.date_key = r.date_key
LEFT JOIN rate rt ON rt.emp_id = r.emp_id AND rt.payroll_month = r.year_month
