WITH emp_month AS (
    SELECT de.emp_id, p.payroll_month, p.department_key, SUM(p.amount) AS cost_pkr
    FROM warehouse.fact_payroll_line p
    JOIN warehouse.dim_employee de ON de.employee_key = p.employee_key
    WHERE p.component_type = 'EARNING'
    GROUP BY de.emp_id, p.payroll_month, p.department_key
)
SELECT d.plant, d.dept_name AS department, em.emp_id, em.payroll_month,
       ROUND(em.cost_pkr, 0) AS payroll_cost_pkr,
       ROUND(LAG(em.cost_pkr) OVER w, 0) AS previous_month_pkr,
       ROUND(em.cost_pkr - LAG(em.cost_pkr) OVER w, 0) AS mom_change_pkr,
       ROUND(100.0 * (em.cost_pkr / LAG(em.cost_pkr) OVER w - 1), 2) AS mom_change_pct
FROM emp_month em JOIN warehouse.dim_department d ON d.department_key = em.department_key
WINDOW w AS (PARTITION BY em.emp_id ORDER BY em.payroll_month)
ORDER BY d.plant, d.dept_name, em.emp_id, em.payroll_month
