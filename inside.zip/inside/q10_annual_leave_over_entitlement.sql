WITH annual AS (
    SELECT de.emp_id, COUNT(DISTINCT f.date_key) AS annual_leave_days, COUNT(DISTINCT f.request_id) AS requests,
           MIN(f.date_key) AS first_day_key, MAX(f.date_key) AS last_day_key
    FROM warehouse.fact_leave_day f
    JOIN warehouse.dim_employee de ON de.employee_key = f.employee_key
    WHERE f.leave_type = 'Annual'
    GROUP BY de.emp_id
)
SELECT a.emp_id, cur.full_name, dep.dept_name AS department, dep.plant,
       cur.annual_leave_entitlement AS full_year_entitlement, a.annual_leave_days AS annual_days_approved_apr_sep,
       a.annual_leave_days - cur.annual_leave_entitlement AS days_over_entitlement, a.requests
FROM annual a
JOIN warehouse.dim_employee cur ON cur.emp_id = a.emp_id AND cur.is_current = 1
JOIN warehouse.dim_department dep ON dep.department_key = cur.department_key
WHERE a.annual_leave_days > cur.annual_leave_entitlement
ORDER BY days_over_entitlement DESC, a.emp_id
