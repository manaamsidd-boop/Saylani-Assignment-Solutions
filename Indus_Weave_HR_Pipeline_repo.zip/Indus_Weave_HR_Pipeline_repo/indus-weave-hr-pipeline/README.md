# Indus Weave Textiles -- HR pipeline (PeopleOps Data Hackathon)

Raw HCM exports -> `raw` -> `staging` -> `warehouse` (star schema) -> 10 SQL answers -> CFO findings.
Engine: SQLite (three attached database files named `raw`, `staging`, `warehouse`, so queries read like PostgreSQL schemas).

## What you get

|Path|Content|
|-|-|
|`db/raw.db`, `db/staging.db`, `db/warehouse.db`|the three layers|
|`warehouse/ddl/`|CREATE TABLE scripts (keys, foreign keys, CHECK constraints)|
|`warehouse/erd.png`|ER diagram drawn from the live schema|
|`analytics/q01\_\*.sql ... q10\_\*.sql`|one SQL file per business question (plus `q09b` and the evidence query)|
|`analytics/results/`|one CSV per question|
|`quality/dq\_results.csv`|every data quality check and its result (also table `warehouse.dq\_results`)|
|`presentation/cfo\_findings.md`, `slides.pdf`, `dashboard.png`|CFO findings, 6-slide deck, dashboard|

## Design decisions

* **Raw is untouched**: all text, JSON kept as one payload per object, `\_source\_file`, `\_loaded\_at`, `\_row\_hash`; idempotent through the hash primary key.
* **Every raw row is accounted for**: staging + logged rejections = raw, for all 12 files.
* **Employment history** is the source of truth; `effective\_to` is ignored and recomputed (valid until the day before the next record). Same-day collisions keep the higher-priority change.
* **Device clock**: found by comparing each device's median check-in offset with its peers per day; `DEV-SITE-01` runs +60 minutes from 2026-07-01; corrected in code.
* **Night shifts** are dated by shift start using the roster of the previous day; Sundays never start a night shift.
* **Monthly figures** use the SCD2 version valid on the month-end date, or the last working day if the employee left that month.
* **Late / early** thresholds compare exact seconds against 10 minutes; overtime floors to half-hours.

## Definitions chosen where the brief leaves room

* Absenteeism % = Absent days / (scheduled days that are not on approved leave).
* Attrition % = separations / ((opening + closing headcount) / 2).
* "Zero attendance" (Q7) = no Present and no Missing Punch day in the month; explained cases are labelled.
* Q9 is cost per paid employee by department; employee-level detail is in `q09b`.
* Q10 counts distinct Annual leave days (Sundays and plant holidays excluded) against the full-year entitlement.

