
CREATE TABLE warehouse.fact_attendance_daily (
    attendance_key          INTEGER PRIMARY KEY,
    employee_key            INTEGER NOT NULL REFERENCES dim_employee (employee_key),
    department_key          INTEGER NOT NULL REFERENCES dim_department (department_key),
    shift_key               INTEGER NOT NULL REFERENCES dim_shift (shift_key),
    date_key                INTEGER NOT NULL REFERENCES dim_date (date_key),
    status                  TEXT    NOT NULL CHECK (status IN ('Present', 'Absent', 'On Leave', 'Holiday', 'Weekly Off', 'Missing Punch')),
    is_sunday               INTEGER NOT NULL,
    is_holiday              INTEGER NOT NULL,
    is_scheduled_day        INTEGER NOT NULL,
    check_in                TEXT,
    check_out               TEXT,
    n_punches               INTEGER NOT NULL,
    worked_hours            REAL,
    is_late                 INTEGER NOT NULL,
    late_minutes            INTEGER NOT NULL,
    is_early_departure      INTEGER NOT NULL,
    early_departure_minutes INTEGER NOT NULL,
    overtime_hours          REAL    NOT NULL,
    UNIQUE (employee_key, date_key)
);

CREATE TABLE warehouse.fact_leave_day (
    leave_day_key   INTEGER PRIMARY KEY,
    request_id      TEXT    NOT NULL,
    employee_key    INTEGER NOT NULL REFERENCES dim_employee (employee_key),
    department_key  INTEGER NOT NULL REFERENCES dim_department (department_key),
    date_key        INTEGER NOT NULL REFERENCES dim_date (date_key),
    leave_type      TEXT    NOT NULL CHECK (leave_type IN ('Annual', 'Casual', 'Sick')),
    UNIQUE (request_id, date_key)
);

CREATE TABLE warehouse.fact_overtime_approved (
    overtime_key     INTEGER PRIMARY KEY,
    request_id       TEXT    NOT NULL UNIQUE,
    employee_key     INTEGER NOT NULL REFERENCES dim_employee (employee_key),
    department_key   INTEGER NOT NULL REFERENCES dim_department (department_key),
    date_key         INTEGER NOT NULL REFERENCES dim_date (date_key),
    requested_hours  REAL    NOT NULL,
    approved_hours   REAL    NOT NULL CHECK (approved_hours > 0),
    approver_id      TEXT
);

CREATE TABLE warehouse.fact_payroll_line (
    payroll_line_key INTEGER PRIMARY KEY,
    line_id          TEXT    NOT NULL UNIQUE,
    employee_key     INTEGER NOT NULL REFERENCES dim_employee (employee_key),
    department_key   INTEGER NOT NULL REFERENCES dim_department (department_key),
    month_end_key    INTEGER NOT NULL REFERENCES dim_date (date_key),
    payroll_month    TEXT    NOT NULL,
    component        TEXT    NOT NULL CHECK (component IN ('BASIC', 'HOUSE_RENT', 'MEDICAL', 'CONVEYANCE', 'OVERTIME', 'INCOME_TAX', 'EOBI', 'ABSENCE_DEDUCTION', 'LOAN_INSTALLMENT')),
    component_type   TEXT    NOT NULL CHECK (component_type IN ('EARNING', 'DEDUCTION')),
    units            REAL,
    amount           REAL    NOT NULL
);
CREATE INDEX warehouse.ix_fpl_emp ON fact_payroll_line (employee_key, payroll_month);
CREATE INDEX warehouse.ix_fad_emp ON fact_attendance_daily (employee_key, date_key);
