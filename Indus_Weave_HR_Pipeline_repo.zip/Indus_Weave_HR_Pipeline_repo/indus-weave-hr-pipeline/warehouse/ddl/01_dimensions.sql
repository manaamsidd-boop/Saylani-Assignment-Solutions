
DROP TABLE IF EXISTS warehouse.fact_payroll_line;
DROP TABLE IF EXISTS warehouse.fact_overtime_approved;
DROP TABLE IF EXISTS warehouse.fact_leave_day;
DROP TABLE IF EXISTS warehouse.fact_attendance_daily;
DROP VIEW  IF EXISTS warehouse.vw_employee_month;
DROP TABLE IF EXISTS warehouse.dim_employee;
DROP TABLE IF EXISTS warehouse.dim_shift;
DROP TABLE IF EXISTS warehouse.dim_department;
DROP TABLE IF EXISTS warehouse.dim_date;

CREATE TABLE warehouse.dim_date (
    date_key         INTEGER PRIMARY KEY,
    full_date        TEXT    NOT NULL UNIQUE,
    year_no          INTEGER NOT NULL,
    quarter_no       INTEGER NOT NULL,
    month_no         INTEGER NOT NULL,
    month_name       TEXT    NOT NULL,
    year_month       TEXT    NOT NULL,
    day_of_month     INTEGER NOT NULL,
    day_of_week_no   INTEGER NOT NULL CHECK (day_of_week_no BETWEEN 0 AND 6),
    day_name         TEXT    NOT NULL,
    is_sunday        INTEGER NOT NULL CHECK (is_sunday IN (0, 1)),
    is_month_end     INTEGER NOT NULL CHECK (is_month_end IN (0, 1)),
    month_start      TEXT    NOT NULL,
    month_end        TEXT    NOT NULL
);

CREATE TABLE warehouse.dim_department (
    department_key   INTEGER PRIMARY KEY,
    dept_id          TEXT    NOT NULL UNIQUE,
    dept_name        TEXT    NOT NULL,
    plant            TEXT    NOT NULL,
    cost_center      TEXT    NOT NULL,
    previous_name    TEXT,
    renamed_on       TEXT
);

CREATE TABLE warehouse.dim_shift (
    shift_key        INTEGER PRIMARY KEY,
    shift_code       TEXT    NOT NULL UNIQUE,
    shift_name       TEXT    NOT NULL,
    start_time       TEXT    NOT NULL,
    end_time         TEXT    NOT NULL,
    crosses_midnight INTEGER NOT NULL CHECK (crosses_midnight IN (0, 1)),
    grace_minutes    INTEGER NOT NULL
);

CREATE TABLE warehouse.dim_employee (
    employee_key             INTEGER PRIMARY KEY,
    emp_id                   TEXT    NOT NULL,
    version_no               INTEGER NOT NULL,
    full_name                TEXT    NOT NULL,
    gender                   TEXT,
    date_of_birth            TEXT,
    email                    TEXT,
    phone                    TEXT,
    hire_date                TEXT    NOT NULL,
    separation_date          TEXT,
    employment_type          TEXT,
    status                   TEXT,
    annual_leave_entitlement INTEGER NOT NULL,
    designation              TEXT,
    grade                    TEXT,
    basic_salary             REAL,
    change_reason            TEXT,
    department_key           INTEGER NOT NULL REFERENCES dim_department (department_key),
    valid_from               TEXT    NOT NULL,
    valid_to                 TEXT    NOT NULL,
    is_current               INTEGER NOT NULL CHECK (is_current IN (0, 1)),
    UNIQUE (emp_id, version_no),
    UNIQUE (emp_id, valid_from),
    CHECK (valid_from <= valid_to)
);
CREATE INDEX warehouse.ix_dim_emp_span ON dim_employee (emp_id, valid_from, valid_to);
